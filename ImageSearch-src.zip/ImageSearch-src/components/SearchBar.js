import React from "react";

class SearchBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = { inputValue: "" };
  }

  onFormSubmit = e => {
    e.preventDefault();
    this.props.onSubmit(this.state.inputValue);
  };

  handleChange = e => {
    console.log(e.target.value);
    this.setState({ inputValue: e.target.value },function(){
      this.props.onTextChange(this.state.inputValue);
    });
  }

  render() {
    return (
      <div className="ui segment">
        <form className="ui form" onSubmit={this.onFormSubmit}>
          <div className="field">
            <label>Image Search</label>
            <input
              type="text"
              placeholder="Search..."
              onChange={this.handleChange}
              value={this.state.inputValue}
            />
          </div>
        </form>
      </div>
    );
  }
}
export default SearchBar;
