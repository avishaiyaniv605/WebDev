import React from "react";
import unsplash from "../api/unsplash";
import SearchBar from "./SearchBar";
import ImageList from "./ImageList";

var numOfPages = 1;

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { images: [], searchTerm: "", numOfPages: 0 };
    this.updateState = this.updateState.bind(this);
    window.addEventListener("scroll", this.handleScroll);
  }

  handleScroll = () => {
      if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
        numOfPages++;
        this.onSearchSubmit(numOfPages);
      }
  };

  onSearchSubmit = async () => {
    const searchResult = await unsplash.get("/search/photos", {
      params: { query: this.state.searchTerm }
    });
    this.setState({ images: searchResult.data.results });
  };

  updateState(searchTerm) {
    console.log(searchTerm);
    this.setState({ searchTerm: searchTerm });
  }

  render() {
    return (
      <div className="ui container" style={{ marginTop: "10px" }}>
        <SearchBar
          onSubmit={this.onSearchSubmit}
          onTextChange={this.updateState}
        />
        <ImageList images={this.state.images} />
      </div>
    );
  }
}
export default App;
