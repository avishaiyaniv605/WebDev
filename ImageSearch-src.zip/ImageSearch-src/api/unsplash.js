import axios from "axios";

export default axios.create({
  baseURL: "https://api.unsplash.com",
  headers: {
    Authorization:
      "Client-ID 31cacbcda1eb86706a079cc00ce93e98299f56053249c72be25e7865c1d51003"
  }
});
