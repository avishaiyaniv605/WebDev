import './SeasonDisplay.css';
import React from "react";

const getSeason = (lat, month) => {
  if (month > 2 && month < 9) {
    return lat > 0 ? "summer" : "winter";
  } else {
    return lat <= 0 ? "summer" : "winter";
  }
};

const seasonConfig = {
    summer: {
        displayText: 'lets hit the beach',
        iconName: 'sun'
    },
    winter: {
        displayText: 'Burr it is chilly',
        iconName: 'snoflake'
    }
}

const SeasonDisplay = props => {
  const season = getSeason(props.lat, new Date().getMonth());
  const configuration = seasonConfig[season];
  return (
    <div className={`season-display ${season}`}>
      <i className={`icon-left massive ${configuration.iconName} icon`} />
      <h1>{configuration.displayText}</h1>
      <i className={`icon-right massive  ${configuration .iconName} icon`} />
    </div>
  );
};

export default SeasonDisplay;
