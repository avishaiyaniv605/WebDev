import React from "react";

const VideoDisplayer = ({ video }) => {
  if (!video) return <div></div>;
  const videoSrc = `https://www.youtube.com/embed/${video.id.videoId}`;
  return (
    <div className="ui embed">
      <iframe title="video player" allowfullscreen="true" src={videoSrc} />
    </div>
  );
};

export default VideoDisplayer;
